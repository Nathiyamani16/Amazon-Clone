export const firebaseConfig = {
  apiKey: "AIzaSyCVZtmB0rq-A5k4GyWvIGsMKFiPnvn90Nc",
  authDomain: "eshop-440e0.firebaseapp.com",
  projectId: "eshop-440e0",
  storageBucket: "eshop-440e0.appspot.com",
  messagingSenderId: "309171374981",
  appId: "1:309171374981:web:97091e4907cdfbc58c92ec",
  measurementId: "G-444ZCFPSZV"
};
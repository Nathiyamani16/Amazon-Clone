import './banner.scss';

const Banner = () => {
  return(
    <div className='banner'>
      <img src="https://m.media-amazon.com/images/I/81KVdS+84PL._SX3000_.jpg" alt=''/>
    </div>
  )
}

export default Banner;